 const accessKey = 'j9RMGqfSWoqY5UBo8zAaelpIKEcVQKDZ92JR0Isw6sY';
    const form = document.getElementById('search-form');
    const queryInput = document.getElementById('query');
    const imageContainer = document.getElementById('image-container');
    const errorMessage = document.getElementById('error');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const query = queryInput.value.trim();
      if (!query) return;

      imageContainer.innerHTML = '<div class="text-center mt-4"><div class="spinner-border text-success" role="status"></div><p>Loading...</p></div>';
      errorMessage.textContent = '';

      try {
        const images = await fetchImages(query);

        if (images.length === 0) {
          imageContainer.innerHTML = '';
          errorMessage.textContent = "No images found for this search.";
          return;
        }

        displayImages(images);
      } catch (error) {
        imageContainer.innerHTML = '';
        errorMessage.textContent = "Error fetching images.";
        console.error(error);
      }
    });

    async function fetchImages(searchQuery) {
      const response = await fetch(`https://api.unsplash.com/search/photos?query=${searchQuery}&client_id=${accessKey}`);
      if (!response.ok) {
        throw new Error("Failed to fetch images");
      }
      const data = await response.json();
      return data.results;
    }

    function displayImages(images) {
      imageContainer.innerHTML = '';
      images.forEach(img => {
        const imgElement = document.createElement('img');
        imgElement.src = img.urls.small;
        imgElement.alt = img.alt_description || "Unsplash image";
        imageContainer.appendChild(imgElement);
      });
    }